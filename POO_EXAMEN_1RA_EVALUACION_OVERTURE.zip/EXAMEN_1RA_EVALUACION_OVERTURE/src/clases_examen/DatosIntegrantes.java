package clases_examen;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author evelyn
 */
public class DatosIntegrantes {
String Equipo;
String Nombre1;
String Nombre2;
int Control1;
int control2;
String Carrera;
   
    
}
