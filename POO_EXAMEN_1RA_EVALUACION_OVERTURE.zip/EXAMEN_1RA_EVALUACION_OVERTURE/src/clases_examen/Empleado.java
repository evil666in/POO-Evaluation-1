/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases_examen;

/**
 *
 * @author OVERTURE
 */
public class Empleado {
   private String nombre;
   private String apellido;
   private String direccion;
   private int anioIngreso;
   private double salario;
   
   public Empleado() {
       nombre = "";
       apellido = "";
       direccion = "";
       anioIngreso = 0;
       salario = 0;
   }

   public Empleado(String nombre, String apellido, String direccion, int anioIngreso, double salario) {
       this.nombre = nombre;
       this.apellido = apellido;
       this.direccion = direccion;
       this.anioIngreso = anioIngreso;
       this.salario = salario;
   }

   public void setNombre(String nombres) {
       nombre = nombres;
   }

   public String getNombre() {
       return nombre;
   }

   public void setApellido(String apellidos) {
       apellido = apellidos;
   }

   public String getApellido() {
       return apellido;
   }

   public void setDireccion(String Direccion) {
       direccion = Direccion;
   }

   public String getDireccion() {
       return direccion;
   }

   public void setAnioIngreso(int anioIng) {
       anioIngreso = anioIng;
   }

   public int getAnioIngreso() {
       return anioIngreso;
   }

   public void setSalario(double valor) {
       salario = valor;
   }

   public double getSalario() {
       return salario;
   }

   public int calcularVacaciones() {
       int antiguedad = 2024 - anioIngreso;
       int vacaciones = 6;
       int adicionales = antiguedad / 5;

       vacaciones += adicionales * 2;
       vacaciones += (antiguedad - adicionales * 5) * 2;

       return vacaciones;
   }

   public void imprimirDatos() {
       System.out.println("Nombre: " + nombre);
       System.out.println("Apellido: " + apellido);
       System.out.println("Dirección: " + direccion);
       System.out.println("Año de ingreso: " + anioIngreso);
       System.out.println("Salario: " + salario);
       System.out.println("Días de vacaciones: " + calcularVacaciones());
   }
}
