/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases_examen;

/**
 *
 * @author evelyn
 */
public class Fibonacci {
  private int n;
  private int a1;
  private int a2;

  public Fibonacci() {
      this.n = 6;
      this.a1 = 1;
      this.a2 = 1;
  }

  public Fibonacci(int n, int a1, int a2) {
      this.n = n;
      this.a1 = a1;
      this.a2 = a2;
  }

  public void setN(int n) {
      this.n = n;
  }

  public int getN() {
      return n;
  }

  public void setA1(int a1) {
      this.a1 = a1;
  }

  public int getA1() {
      return a1;
  }

  public void setA2(int a2) {
      this.a2 = a2;
  }

  public int getA2() {
      return a2;
  }

  public void imprimirSerie() {
      System.out.print(a1 + " – " + a2);
      int actual = a1 + a2;
      int siguiente = actual + a2;

      for (int i = 3; i <= n; i++) {
          System.out.print(" – " + actual);
          actual = siguiente;
          siguiente = actual + siguiente;
      }

      System.out.println();
  }
}
