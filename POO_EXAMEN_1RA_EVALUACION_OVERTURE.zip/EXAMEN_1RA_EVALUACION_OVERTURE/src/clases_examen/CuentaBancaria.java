/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases_examen;

/**
 *
 * @author OVERTURE
 */
public class CuentaBancaria {
   private String numeroCuenta;
   private String nombreCliente;
   private double saldo;

   public CuentaBancaria() {
       numeroCuenta = "";
       nombreCliente = "";
       saldo = 0;
   }

   public void setNumeroCuenta(String NumeroCuenta) {
       numeroCuenta = NumeroCuenta;
   }

   public String getNumeroCuenta() {
       return numeroCuenta;
   }

   public void setNombreCliente(String NombreCliente) {
       nombreCliente = NombreCliente;
   }

   public String getNombreCliente() {
       return nombreCliente;
   }

   public void setSaldo(double valor) {
       saldo = valor;
   }

   public double getSaldo() {
       return saldo;
   }

   public void depositarEnCuenta(double monto) {
       saldo += monto;
   }

   public void retirarDeCuenta(double monto) {
       if (saldo >= monto) {
           saldo -= monto;
       } else {
           System.out.println("--SALDO INSUFICIENTE--");
       }
   }

   public void imprimirDatos() {
       System.out.println("Número de cuenta: " + numeroCuenta);
       System.out.println("Nombre del cliente: " + nombreCliente);
       System.out.println("Saldo: " + saldo);
   }
    
}
