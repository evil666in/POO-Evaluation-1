/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases_examen;

/**
 *
 * @author OVERTURE
 */
public class Pelicula {
    private String titulo;
    private String estudio;
    private int rating;

    /**
     * Constructor sin parámetros
     */
    public Pelicula() {
        this("", "", 0);
    }

    /**
     * Constructor con parámetros.
     *
     * @param titulo   El título de la película
     * @param estudio  El estudio que produjo la película
     * @param rating   La calificación de la película
     */
    public Pelicula(String titulo, String estudio, int rating) {
        this.titulo = titulo;
        this.estudio = estudio;
        this.rating = rating;
    }

    
    public void setTitulo(String nombre) {
        titulo = nombre;
    }

   
    public void setEstudio(String Estudio) {
        estudio = Estudio;
    }

   
    public void setRating(int valor) {
        rating = valor;
    }

    
    public String getTitulo() {
        return titulo;
    }

    
    public String getEstudio() {
        return estudio;
    }

    
    public int getRating() {
        return rating;
    }

    
    public void imprimirDatos() {
        System.out.println("Título: " + titulo);
        System.out.println("Estudio: " + estudio);
        System.out.println("Rating: " + rating);
    }

    /**
     * Método que evalúa si una persona puede ver la película.
     *
     * @param edad La edad de la persona.
     */
    public void evaluarEdad(int edad) {
        if (edad >= rating) {
            System.out.println("Puede ver la película\n");
        } else {
            System.out.println("No puede ver la película\n");
        }
    }
}
