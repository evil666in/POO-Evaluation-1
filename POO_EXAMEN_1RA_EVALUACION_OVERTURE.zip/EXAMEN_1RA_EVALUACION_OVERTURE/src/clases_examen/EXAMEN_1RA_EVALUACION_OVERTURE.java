/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases_examen;

/**
 *
 * @author OVERTURE 
 */
public class EXAMEN_1RA_EVALUACION_OVERTURE {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        DatosIntegrantes datos = new DatosIntegrantes();
        System.out.println(datos);
        
        datos.Equipo = "Overture";
        datos.Nombre1 = "Evelyn Janeth Hernandez Granados";
        datos.Nombre2 = "Michelle Martinez Posada";
        datos.Control1 = 23550386;
        datos.control2 = 23550347;
        datos.Carrera = "Ingenieria en Sistemas Computacionales";
        
        System.out.println("Equipo: " + datos.Equipo);
        System.out.println("Integrantes: " + datos.Nombre1);
        System.out.println(""+ datos.Nombre2);
        System.out.println("Numeros de control: " + datos.Control1);
        System.out.println(""+datos.control2);
        System.out.println("Carrera: " + datos.Carrera);
        
        //Clase PELICULA
                System.out.println("_______________");
        System.out.println("CLASE: PELICULA");
        Pelicula pelicula = new Pelicula();
        pelicula.setTitulo("Poor Things");
        pelicula.setEstudio("Searchlight Pictures");
        pelicula.setRating(+18);
        pelicula.imprimirDatos();
        pelicula.evaluarEdad(21); //Aqui para cambiar la edad y evaluar si puede ver la pelicula 
        
        //Clase CUENTA BANCARIA
        System.out.println("_______________");
        System.out.println("CLASE: CUENTA BANCARIA");
        CuentaBancaria banco = new CuentaBancaria();
        banco.setNombreCliente("Juan Perez");
        banco.setNumeroCuenta("4476");
        banco.setSaldo(0);
        banco.depositarEnCuenta(1500);
        banco.retirarDeCuenta(753);
        banco.depositarEnCuenta(1234); 
        //Aqui podemos verificar que solo podemos retirar dinero con el que contamos (Saldo suficiente)
        //banco.retirarDeCuenta(2000);
        banco.imprimirDatos();
        
        //Clase EMPLEADO
        System.out.println("_______________");
        System.out.println("CLASE: EMPLEADO");
        Empleado persona = new Empleado();
        persona.setNombre("Antonio");
        persona.setApellido("Muñoz");
        persona.setDireccion("Calle 20 de noviembre");
        persona.setAnioIngreso(2018); //Aqui podemos cambiar el año para calcular las vacaiones
        persona.setSalario(50000);
        persona.calcularVacaciones();
        persona.imprimirDatos();
        
        //Clase FIBONACCI
        System.out.println("_______________");
        System.out.println("CLASE: FIBONACCI");
        Fibonacci fibonacci = new Fibonacci(6, 2, 5);
        fibonacci.imprimirSerie();
        
        
    }
    
}
